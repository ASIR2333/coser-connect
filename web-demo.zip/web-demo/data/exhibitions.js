/* data/exhibitions.js - 沿用 mock/exhibition.js，删除 GPS/场馆polygon，仅保留展示字段 */
(function(){
  var now = Date.now(), DAY = 86400000;
  window.DEMO_EXHIBITIONS = [
    { id:"ex1", name:"COMICUP 31 上海同人祭", startTime:now-DAY, endTime:now+DAY, location:"国家会展中心（上海）", region:"上海", phase:"ongoing", phaseText:"进行中",
      zones:["A馆 · 原神专区","A馆 · 明日方舟专区","B馆 · 综合同人区","C馆 · 国风专区"] },
    { id:"ex2", name:"广州萤火虫动漫游戏嘉年华", startTime:now+7*DAY, endTime:now+9*DAY, location:"保利世贸博览馆", region:"广州", phase:"upcoming", phaseText:"未开始",
      zones:["1号馆 · 游戏专区","2号馆 · 综合区"] },
    { id:"ex3", name:"北京 IJOY 国际动漫游戏狂欢节", startTime:now+20*DAY, endTime:now+21*DAY, location:"北京国家会议中心", region:"北京", phase:"upcoming", phaseText:"未开始",
      zones:["E1馆 · 综合区","E2馆 · 同人区"] },
    { id:"ex4", name:"幻星国际动漫游戏博览会", startTime:now-DAY, endTime:now+2*DAY, location:"北京 · 双馆联动", region:"北京", phase:"ongoing", phaseText:"进行中",
      zones:["主会场 · 舞台区","主会场 · 同人区","北展 · 游戏区","北展 · 摄影区"] }
  ];
})();
