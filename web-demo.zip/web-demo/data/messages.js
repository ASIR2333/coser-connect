/* data/messages.js - 通知消息 Mock */
(function(){
  var now = Date.now(), H = 3600000, DAY = 86400000, M = 60000;
  window.DEMO_MESSAGES = [
    { id:"n1", type:"system", title:"欢迎来到漫展集邮", content:"完善你的角色信息，让同场的小伙伴更快找到你！遇到心动的角色，一键发送集邮请求即可。", roleId:"", read:false, createdAt:now-10*M },
    { id:"n2", type:"request", title:"新的集邮请求", content:"「星核猎手_K」想和你集邮，快去处理吧～", roleId:"r3", read:false, createdAt:now-1*H },
    { id:"n3", type:"request", title:"新的集邮请求", content:"「无量空处」想和你集邮，快去处理吧～", roleId:"r5", read:false, createdAt:now-3*H },
    { id:"n4", type:"agree", title:"请求已被接受", content:"「一只小可莉」接受了你的集邮请求，记得去现场找 TA 集邮！", roleId:"r1", read:false, createdAt:now-6*H },
    { id:"n5", type:"reject", title:"请求已被拒绝", content:"「龙门陈警官」拒绝了你的集邮请求，去看看其他角色吧。", roleId:"r9", read:true, createdAt:now-DAY },
    { id:"n6", type:"system", title:"功能上线公告", content:"地图模式 V1.0 已上线！在首页点击「地图模式」，按专区发现同场角色。", roleId:"", read:true, createdAt:now-2*DAY }
  ];
  /* 广场帖子仅 Mock 展示（不可真实发布到服务器） */
  window.DEMO_POSTS = [
    { id:"p1", nickname:"一只小可莉", tag:"场照", content:"今天的芙宁娜场照出炉！A馆原神专区太热闹了，集邮集到手软～", images:["assets/images/ai_example1.png","assets/images/ai_example2.png"], likeCount:42, createdAt:now-3*H },
    { id:"p2", nickname:"无量空处", tag:"求助", content:"B馆综合区有人捡到一顶五条悟的假发吗？捡到请联系我，请喝奶茶！", images:[], likeCount:18, createdAt:now-5*H },
    { id:"p3", nickname:"星核猎手_K", tag:"集邮", content:"卡芙卡集邮返图第一弹！感谢各位老师，大家都太还原了", images:["assets/images/ai_example1.png"], likeCount:56, createdAt:now-8*H },
    { id:"p4", nickname:"哇库哇库", tag:"日常", content:"阿尼亚今天被围观了哈哈哈，哇库哇库！花生都不够分了", images:["assets/images/ai_example2.png"], likeCount:88, createdAt:now-10*H }
  ];
})();
