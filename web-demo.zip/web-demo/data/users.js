/* data/users.js - 沿用 mock/user.js，删除 openid */
window.DEMO_USERS = [
  { id:"u1", nickname:"一只小可莉", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u2", nickname:"雷电影的团子", avatar:"assets/images/avatar.png", status:"active" },
  { id:"u3", nickname:"星核猎手_K", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u4", nickname:"罗德岛摸鱼中", avatar:"assets/images/avatar.png", status:"active" },
  { id:"u5", nickname:"无量空处", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u6", nickname:"哇库哇库", avatar:"assets/images/avatar.png", status:"active" },
  { id:"u7", nickname:"千年魔法使", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u8", nickname:"草之王", avatar:"assets/images/avatar.png", status:"active" },
  { id:"u9", nickname:"龙门陈警官", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u10", nickname:"蝶屋敷常客", avatar:"assets/images/avatar.png", status:"active" },
  { id:"u11", nickname:"封印解除", avatar:"assets/images/avatar2.png", status:"active" },
  { id:"u12", nickname:"往生堂客卿", avatar:"assets/images/avatar.png", status:"active" }
];
window.DEMO_ME = { id:"u_me", nickname:"我自己", avatar:"assets/images/avatar.png", status:"active", accepting:true, statusText:"欢迎来集邮" };
