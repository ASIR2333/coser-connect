/* data/requests.js - 沿用 mock/request.js 状态机 pending/accepted/rejected */
(function(){
  var now = Date.now(), H = 3600000, DAY = 86400000;
  window.DEMO_REQUESTS = [
    { id:"req_seed_1", senderId:"u3", receiverId:"u_me", roleId:"r3", message:"你好呀，看到你的角色卡了，可以集邮吗～", status:"pending", createdAt:now-1*H,
      roleSnapshot:{ roleId:"r3", ip:"崩坏：星穹铁道", roleName:"卡芙卡", avatar:"assets/images/avatar2.png", area:"B馆 · 综合同人区", ownerNickname:"星核猎手_K" } },
    { id:"req_seed_2", senderId:"u5", receiverId:"u_me", roleId:"r5", message:"同好！求集邮，我在 B 馆门口～", status:"pending", createdAt:now-3*H,
      roleSnapshot:{ roleId:"r5", ip:"咒术回战", roleName:"五条悟", avatar:"assets/images/avatar2.png", area:"B馆 · 综合同人区", ownerNickname:"无量空处" } },
    { id:"req_seed_3", senderId:"u_me", receiverId:"u1", roleId:"r1", message:"芙宁娜大人求合影！", status:"accepted", createdAt:now-6*H,
      roleSnapshot:{ roleId:"r1", ip:"原神", roleName:"芙宁娜", avatar:"assets/images/avatar2.png", area:"A馆 · 原神专区", ownerNickname:"一只小可莉" } },
    { id:"req_seed_4", senderId:"u_me", receiverId:"u9", roleId:"r9", message:"陈 sir 可以集邮吗", status:"rejected", createdAt:now-DAY,
      roleSnapshot:{ roleId:"r9", ip:"明日方舟", roleName:"陈", avatar:"assets/images/avatar2.png", area:"A馆 · 明日方舟专区", ownerNickname:"龙门陈警官" } }
  ];
})();
