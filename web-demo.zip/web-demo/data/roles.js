/* data/roles.js - 沿用 mock/role.js，删除 lat/lng/venueId/zoneId，avatar 改本地 */
(function(){
  var now = Date.now(), H = 3600000, DAY = 86400000;
  function R(id,userId,exhibitionId,ip,roleName,avatar,area,status,intro,createdAt){
    var map = { available:"可集邮", busy:"忙碌中", rest:"休息中" };
    return { id:id, userId:userId, exhibitionId:exhibitionId, ip:ip, characterName:roleName, roleName:roleName, avatar:avatar, area:area, status:status, statusText:map[status], intro:intro, createdAt:createdAt };
  }
  window.DEMO_ROLES = [
    R("r1","u1","ex1","原神","芙宁娜","assets/images/avatar2.png","A馆 · 原神专区","available","水神大人驾到！欢迎来集邮，会带小道具～",now-5*H),
    R("r2","u2","ex1","原神","雷电将军","assets/images/avatar.png","A馆 · 原神专区","available","永恒之下，与你合影。",now-8*H),
    R("r3","u3","ex1","崩坏：星穹铁道","卡芙卡","assets/images/avatar2.png","B馆 · 综合同人区","available","听我说：来集邮吧。",now-12*H),
    R("r4","u4","ex1","明日方舟","阿米娅","assets/images/avatar.png","A馆 · 明日方舟专区","busy","博士，一起加油吧！下午场照拍摄中，三点后可集邮。",now-DAY),
    R("r5","u5","ex1","咒术回战","五条悟","assets/images/avatar2.png","B馆 · 综合同人区","available","没关系，我可是最强的。眼罩可摘～",now-2*H),
    R("r6","u6","ex1","间谍过家家","阿尼亚","assets/images/avatar.png","B馆 · 综合同人区","available","哇库哇库！想和大家集邮！",now-3*H),
    R("r7","u7","ex1","葬送的芙莉莲","芙莉莲","assets/images/avatar2.png","B馆 · 综合同人区","rest","旅行途中休息一下……傍晚回来。",now-6*H),
    R("r8","u8","ex1","原神","纳西妲","assets/images/avatar.png","A馆 · 原神专区","busy","正在参加舞台活动，结束后可约。",now-10*H),
    R("r9","u9","ex1","明日方舟","陈","assets/images/avatar2.png","A馆 · 明日方舟专区","rest","龙门近卫局，暂离岗位午休中。",now-15*H),
    R("r10","u10","ex1","鬼灭之刃","蝴蝶忍","assets/images/avatar.png","C馆 · 国风专区","available","啊啦啊啦，要一起拍吗？",now-4*H),
    R("r11","u11","ex1","魔卡少女樱","木之本樱","assets/images/avatar2.png","C馆 · 国风专区","available","封印解除！经典战斗服参上～",now-7*H),
    R("r12","u12","ex1","原神","胡桃","assets/images/avatar.png","A馆 · 原神专区","available","往生堂第七十七代堂主，集邮送打油诗一首！",now-1*H),
    R("r13","u1","ex2","原神","可莉","assets/images/avatar2.png","1号馆 · 游戏专区","available","蹦蹦炸弹！广州见～",now-2*DAY),
    R("r14","u5","ex2","咒术回战","夏油杰","assets/images/avatar.png","2号馆 · 综合区","available","咒灵操使，欢迎同好。",now-DAY),
    R("r15","u2","ex4","原神","钟离","assets/images/avatar.png","主会场 · 同人区","available","契约既成，食言者当受食岩之罚。",now-3*H),
    R("r16","u6","ex4","间谍过家家","约尔","assets/images/avatar.png","主会场 · 舞台区","busy","荆棘公主，舞台活动后可集邮。",now-5*H),
    R("r17","u8","ex4","原神","温迪","assets/images/avatar.png","主会场 · 同人区","available","诶嘿～要来一杯苹果酒吗？",now-6*H),
    R("r18","u10","ex4","鬼灭之刃","灶门祢豆子","assets/images/avatar.png","北展 · 游戏区","available","欢迎来抓～",now-8*H),
    R("r19","u4","ex4","明日方舟","能天使","assets/images/avatar.png","北展 · 摄影区","rest","苹果派补给中！",now-9*H),
    R("r20","u12","ex4","原神","魈","assets/images/avatar.png","北展 · 游戏区","available","降魔大圣，集邮可以。",now-10*H)
  ];
})();
