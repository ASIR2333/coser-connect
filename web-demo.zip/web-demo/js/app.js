/* js/app.js - 页面 render：home / 集邮 / publish / message / mine / detail / exhibitions / map / square */
(function(){
  var S = { keyword:"", ip:"全部", area:"全部", status:"", viewMode:"card", reqType:"received", pubImg:"" };
  S.viewMode = Store.get("view_mode","card");

  function applyTheme(){
    var t = Store.get("theme","light");
    document.documentElement.setAttribute("data-theme", t);
    var b = document.getElementById("theme-btn");
    if(b) b.textContent = t==="light" ? "🌙 深色" : "☀️ 浅色";
  }
  function toggleTheme(){
    var t = Store.get("theme","light")==="light"?"dark":"light";
    Store.save("theme", t); applyTheme(); UI.toast(t==="dark"?"已切换深色模式":"已切换浅色模式");
  }

  function setTabbar(){
    var r = Router.get();
    var tabs = [["home","🏠","首页"],["jipiao","📮","集邮"],["publish","➕","发布"],["message","🔔","消息"],["mine","👤","我的"]];
    var unread = State.unreadCount();
    var el = document.getElementById("tabbar");
    el.innerHTML = tabs.map(function(t){
      var dot = (t[0]==="message" && unread>0) ? ' <span class="badge-dot">'+(unread>99?"99+":unread)+'</span>' : "";
      return '<button data-tab="'+t[0]+'" class="'+(r.page===t[0]||(r.page==="detail"&&t[0]==="home")?"active":"")+'"><span class="ico">'+t[1]+'</span>'+t[2]+dot+'</button>';
    }).join("");
    el.querySelectorAll("button").forEach(function(b){ b.onclick = function(){ Router.go(b.getAttribute("data-tab")); }; });
  }

  function render(){ setTabbar(); var r = Router.get(); var v = document.getElementById("view");
    ({ home:renderHome, jipiao:renderJipiao, publish:renderPublish, message:renderMessage, mine:renderMine,
       detail:renderDetail, exhibitions:renderExhibitions, map:renderMap, square:renderSquare })[r.page](v, r.params);
  }

  /* ---------- 首页 ---------- */
  function renderHome(v){
    var ex = Store.get("currentExhibition", window.DEMO_EXHIBITIONS[0]);
    var roles = State.allRoles();
    var ips = ["全部"].concat(Array.from(new Set(roles.map(function(r){return r.ip;}))));
    var areas = ["全部"].concat(ex.zones||[]);
    var list = roles.filter(function(r){
      if(S.ip!=="全部" && r.ip!==S.ip) return false;
      if(S.area!=="全部" && r.area!==S.area) return false;
      if(S.status && r.status!==S.status) return false;
      if(S.keyword){ var k=S.keyword.trim(); if(k && r.roleName.indexOf(k)<0 && r.ip.indexOf(k)<0) return false; }
      return true;
    }).sort(function(a,b){return b.createdAt-a.createdAt;});
    v.innerHTML = UI.exhibitionCard(ex) +
      '<div class="header-actions"><button id="h-switch">⇄ 切换展会</button><button id="h-map">◎ 地图模式</button><button id="h-square">🖼️ 逛广场</button></div>' +
      '<div class="search-row"><div class="search-box"><input id="h-kw" placeholder="搜索角色 / IP，如：原神" value="'+Utils.esc(S.keyword)+'"/></div></div>' +
      '<div class="chips">'+ips.map(function(ip){return '<button class="chip '+(S.ip===ip?"active":"")+'" data-ip="'+Utils.esc(ip)+'">'+Utils.esc(ip)+'</button>';}).join("")+'</div>' +
      '<div class="section-head"><span>同场角色 · 发现集邮</span><span class="count">共 '+list.length+' 人 · <a href="javascript:void(0)" id="h-mode">'+(S.viewMode==="card"?"☰ 切列表":"▦ 切卡片")+'</a></span></div>' +
      '<div class="filter-bar"><select id="h-area">'+areas.map(function(a){return '<option '+(S.area===a?"selected":"")+'>'+Utils.esc(a)+'</option>';}).join("")+'</select>' +
      '<select id="h-status"><option value="">全部状态</option><option value="available" '+(S.status==="available"?"selected":"")+'>可集邮</option><option value="busy" '+(S.status==="busy"?"selected":"")+'>忙碌中</option><option value="rest" '+(S.status==="rest"?"selected":"")+'>休息中</option></select></div>' +
      '<div id="h-list">'+ (list.length ? (S.viewMode==="card" ? '<div class="role-grid">'+list.map(function(r){return UI.roleCard(r,"card");}).join("")+'</div>' : list.map(function(r){return UI.roleCard(r,"list");}).join("")) : UI.emptyState("🎭","还没有符合条件的角色","去「发布」页上传你的角色，成为第一个吧","发布角色","h-pub")) +'</div>';
    document.getElementById("ex-card").onclick = function(){ Router.go("exhibitions"); };
    document.getElementById("h-switch").onclick = function(){ Router.go("exhibitions"); };
    document.getElementById("h-map").onclick = function(){ Router.go("map"); };
    document.getElementById("h-square").onclick = function(){ Router.go("square"); };
    var kw = document.getElementById("h-kw");
    kw.oninput = Utils.debounce(function(){ S.keyword = kw.value; renderHome(v); var n=document.getElementById("h-kw"); n.focus(); n.setSelectionRange(n.value.length,n.value.length); }, 400);
    v.querySelectorAll("[data-ip]").forEach(function(b){ b.onclick=function(){ S.ip=b.getAttribute("data-ip"); render(); }; });
    document.getElementById("h-area").onchange = function(e){ S.area=e.target.value; render(); };
    document.getElementById("h-status").onchange = function(e){ S.status=e.target.value; render(); };
    document.getElementById("h-mode").onclick = function(){ S.viewMode = S.viewMode==="card"?"list":"card"; Store.save("view_mode",S.viewMode); render(); };
    v.querySelectorAll("[data-role]").forEach(function(c){ c.onclick=function(){ Router.go("detail",{id:c.getAttribute("data-role")}); }; });
    var pub = document.getElementById("h-pub"); if(pub) pub.onclick=function(){ Router.go("publish"); };
  }

  /* ---------- 角色详情 ---------- */
  function renderDetail(v, p){
    var r = State.allRoles().find(function(x){return x.id===p.id;}) || window.DEMO_ROLES.find(function(x){return x.id===p.id;});
    if(!r){ v.innerHTML = UI.emptyState("😵","角色不存在或已下展","", "返回首页","d-back"); document.getElementById("d-back").onclick=function(){Router.go("home");}; return; }
    var me = Store.get("currentUser", window.DEMO_ME);
    var isSelf = r.userId===me.id;
    var pending = State.allRequests().some(function(x){return x.senderId==="u_me"&&x.roleId===r.id&&x.status==="pending";});
    v.innerHTML = '<button class="btn btn-plain btn-small" id="d-back">‹ 返回</button><div style="height:8px"></div>' +
      '<img class="detail-cover" src="'+Utils.esc(r.avatar)+'"/>' +
      '<div class="card" style="margin-top:10px"><div style="display:flex;align-items:center;gap:8px"><span style="font-size:18px;font-weight:800">'+Utils.esc(r.roleName)+'</span>'+UI.statusTag(r.status,r.statusText)+'</div>' +
      '<div style="color:var(--primary);font-size:13px;margin:4px 0">'+Utils.esc(r.ip)+' · '+Utils.esc(State.nickname(r.userId))+'</div>' +
      '<div class="kv"><span>所在区域</span><span>'+Utils.esc(r.area)+'</span></div>' +
      '<div class="kv"><span>发布时间</span><span>'+Utils.formatRelative(r.createdAt)+'</span></div>' +
      '<p style="font-size:13px;color:var(--text-secondary);margin-top:8px">'+Utils.esc(r.intro||"这个人很神秘，还没有写简介～")+'</p></div>' +
      '<div style="height:10px"></div>' +
      (isSelf ? '<button class="btn btn-plain" id="d-edit">这是我的角色，去管理 ›</button>'
        : pending ? '<button class="btn btn-primary" disabled>已发送请求，等待对方处理</button>'
        : '<button class="btn btn-primary" id="d-send">📮 发送集邮请求</button>');
    document.getElementById("d-back").onclick = function(){ Router.go("home"); };
    var edit = document.getElementById("d-edit"); if(edit) edit.onclick=function(){ Router.go("publish"); };
    var send = document.getElementById("d-send");
    if(send) send.onclick = function(){
      UI.showModal({ title:"填写留言", content:"向「"+r.roleName+"」打个招呼吧（可选）", showInput:true, confirmText:"下一步" }).then(function(a){
        if(!a.confirm) return;
        UI.showModal({ title:"发送集邮请求", content:"向「"+r.roleName+"」（"+State.nickname(r.userId)+"）发送集邮请求"+(a.value?"，留言："+a.value:"")+"？", confirmText:"发送" }).then(function(b){
          if(!b.confirm) return;
          if(r.userId==="u_me"){ UI.toast("不能给自己的角色发送请求"); return; }
          var list = State.allRequests();
          if(list.some(function(x){return x.senderId==="u_me"&&x.roleId===r.id&&x.status==="pending";})){ UI.toast("你已发送过请求，请等待对方处理"); return; }
          list.unshift({ id:Utils.uuid("req"), senderId:"u_me", receiverId:r.userId, roleId:r.id, message:a.value||"", status:"pending", createdAt:Date.now(),
            roleSnapshot:{ roleId:r.id, ip:r.ip, roleName:r.roleName, avatar:r.avatar, area:r.area, ownerNickname:State.nickname(r.userId) } });
          State.saveRequests(list);
          UI.toast("请求已发送");
          render();
        });
      });
    };
  }

  /* ---------- 集邮（请求列表） ---------- */
  function renderJipiao(v){
    var all = State.allRequests();
    var list = all.filter(function(r){ return S.reqType==="sent" ? r.senderId==="u_me" : r.receiverId==="u_me"; })
      .sort(function(a,b){return b.createdAt-a.createdAt;});
    v.innerHTML = '<div class="section-head"><span>我的集邮</span><span class="count">pending → accepted / rejected</span></div>' +
      '<div class="sub-tabs"><button data-t="received" class="'+(S.reqType==="received"?"active":"")+'">收到的</button><button data-t="sent" class="'+(S.reqType==="sent"?"active":"")+'">发出的</button></div>' +
      '<div id="j-list">'+ (list.length?list.map(UI.requestCard).join(""):UI.emptyState("📮","还没有"+(S.reqType==="sent"?"发出的":"收到的")+"请求","去首页发现心仪角色并发起集邮吧","去首页","j-home")) +'</div>';
    v.querySelectorAll("[data-t]").forEach(function(b){ b.onclick=function(){ S.reqType=b.getAttribute("data-t"); render(); }; });
    var home = document.getElementById("j-home"); if(home) home.onclick=function(){Router.go("home");};
    function refresh(){ State.saveRequests(State.allRequests()); render(); }
    v.querySelectorAll("[data-accept]").forEach(function(b){ b.onclick=function(){
      var l=State.allRequests(); var r=l.find(function(x){return x.id===b.getAttribute("data-accept");});
      r.status="accepted"; r.handledAt=Date.now(); State.saveRequests(l);
      State.pushMessage("agree","请求已被接受","你接受了「"+State.nickname(r.senderId)+"」的集邮请求", r.roleId);
      UI.toast("已接受"); refresh();
    };});
    v.querySelectorAll("[data-reject]").forEach(function(b){ b.onclick=function(){
      var l=State.allRequests(); var r=l.find(function(x){return x.id===b.getAttribute("data-reject");});
      r.status="rejected"; r.handledAt=Date.now(); State.saveRequests(l);
      UI.toast("已拒绝"); refresh();
    };});
    v.querySelectorAll("[data-sim]").forEach(function(b){ b.onclick=function(){
      var l=State.allRequests(); var r=l.find(function(x){return x.id===b.getAttribute("data-sim");});
      r.status="accepted"; r.handledAt=Date.now(); State.saveRequests(l);
      State.pushMessage("agree","请求已被接受","「"+(r.roleSnapshot.ownerNickname||"对方")+"」接受了你的集邮请求，记得去现场找 TA！", r.roleId);
      UI.toast("对方已接受 ✓"); refresh();
    };});
  }

  /* ---------- 发布 ---------- */
  function renderPublish(v){
    var ex = Store.get("currentExhibition", window.DEMO_EXHIBITIONS[0]);
    var mines = Store.get("customRoles",[]).filter(function(r){return r.exhibitionId===ex.id;});
    v.innerHTML = '<div class="section-head"><span>发布角色 · '+Utils.esc(ex.name)+'</span></div>' +
      '<div class="card"><div class="field"><label>角色照片（本地选择，仅浏览器预览 + localStorage 保存）</label>' +
      '<input type="file" id="p-file" accept="image/*"/><img id="p-prev" class="preview-img" style="display:none"/></div>' +
      '<div class="field"><label>IP（如：原神）</label><input id="p-ip" placeholder="请输入 IP"/></div>' +
      '<div class="field"><label>角色名</label><input id="p-name" placeholder="如：芙宁娜"/></div>' +
      '<div class="field"><label>所在区域</label><select id="p-area">'+(ex.zones||[]).map(function(a){return '<option>'+Utils.esc(a)+'</option>';}).join("")+'</select></div>' +
      '<div class="field"><label>当前状态</label><select id="p-status"><option value="available">可集邮</option><option value="busy">忙碌中</option><option value="rest">休息中</option></select></div>' +
      '<div class="field"><label>一句话介绍</label><textarea id="p-intro" placeholder="会带小道具，欢迎来集邮～"></textarea></div>' +
      '<button class="btn btn-primary" id="p-submit">发布</button></div>' +
      '<div class="section-head"><span>我在本展的角色（'+mines.length+'）</span></div><div id="p-mines">' +
      (mines.length?mines.map(function(r){return '<div class="role-list-item"><img src="'+Utils.esc(r.avatar)+'"/><div style="flex:1"><div style="font-weight:700">'+Utils.esc(r.roleName)+'</div><div style="font-size:12px;color:var(--primary)">'+Utils.esc(r.ip)+' · '+Utils.esc(r.area)+'</div></div><button class="btn btn-plain btn-small" data-del="'+r.id+'">删除</button></div>';}).join(""):'<div class="loading">还没有发布，快成为第一个吧～</div>')+'</div>';
    document.getElementById("p-file").onchange = function(e){
      var f = e.target.files[0]; if(!f) return;
      var rd = new FileReader();
      rd.onload = function(){ S.pubImg = rd.result; var im=document.getElementById("p-prev"); im.src=rd.result; im.style.display="block"; };
      rd.readAsDataURL(f);
    };
    document.getElementById("p-submit").onclick = function(){
      var ip=document.getElementById("p-ip").value.trim(), name=document.getElementById("p-name").value.trim();
      if(!ip||!name){ UI.toast("请填写完整的 IP 与角色名"); return; }
      if(!S.pubImg){ UI.toast("请先选择角色照片"); return; }
      var st=document.getElementById("p-status").value;
      var map={available:"可集邮",busy:"忙碌中",rest:"休息中"};
      var all=Store.get("customRoles",[]);
      all.push({ id:Utils.uuid("role"), userId:"u_me", exhibitionId:ex.id, ip:ip, characterName:name, roleName:name,
        avatar:S.pubImg, area:document.getElementById("p-area").value, status:st, statusText:map[st],
        intro:document.getElementById("p-intro").value.trim(), createdAt:Date.now() });
      Store.save("customRoles",all); S.pubImg="";
      UI.toast("发布成功，已出现在首页"); Router.go("home");
    };
    v.querySelectorAll("[data-del]").forEach(function(b){ b.onclick=function(){
      UI.showModal({title:"删除角色",content:"确定删除这个角色吗？",confirmText:"删除"}).then(function(r){
        if(!r.confirm) return;
        Store.save("customRoles", Store.get("customRoles",[]).filter(function(x){return x.id!==b.getAttribute("data-del");}));
        UI.toast("已删除"); render();
      });
    };});
  }

  /* ---------- 消息 ---------- */
  var TYPE_META = { request:["请","type-request"], agree:["同","type-agree"], reject:["拒","type-reject"], system:["告","type-system"] };
  function renderMessage(v){
    var list = State.allMessages().sort(function(a,b){return b.createdAt-a.createdAt;});
    var unread = State.unreadCount();
    v.innerHTML = '<div class="section-head"><span>消息'+(unread?' · 未读 '+unread:"")+'</span>'+(unread?'<a href="javascript:void(0)" id="m-all" style="font-size:12px;color:var(--primary);font-weight:400">全部已读</a>':"")+'</div>' +
      (list.length?list.map(function(m){ var t=TYPE_META[m.type]||TYPE_META.system;
        return '<div class="msg-item" data-mid="'+m.id+'"><div class="avatar '+t[1]+'">'+t[0]+'</div><div style="flex:1"><div style="font-weight:700;font-size:14px">'+Utils.esc(m.title)+(m.read?"":'<span class="unread"></span>')+'</div><div style="font-size:13px;color:var(--text-secondary)">'+Utils.esc(m.content)+'</div><div style="font-size:11px;color:var(--text-weak)">'+Utils.formatRelative(m.createdAt)+'</div></div></div>';
      }).join(""):UI.emptyState("🔔","还没有消息","集邮请求动态会出现在这里","",null));
    var all=document.getElementById("m-all"); if(all) all.onclick=function(){
      var l=State.allMessages(); l.forEach(function(m){m.read=true;}); Store.save("messages",l); render();
    };
    v.querySelectorAll("[data-mid]").forEach(function(c){ c.onclick=function(){
      var l=State.allMessages(); var m=l.find(function(x){return x.id===c.getAttribute("data-mid");});
      m.read=true; Store.save("messages",l);
      if(m.type==="request"){ Router.go("jipiao"); }
      else if(m.roleId){ Router.go("detail",{id:m.roleId}); }
      else { UI.showModal({title:m.title,content:m.content,confirmText:"知道了"}).then(render); }
    };});
  }

  /* ---------- 我的 ---------- */
  function renderMine(v){
    var me = Store.get("currentUser", window.DEMO_ME);
    var t = Store.get("theme","light");
    var sent = State.allRequests().filter(function(r){return r.senderId==="u_me";}).length;
    var mines = Store.get("customRoles",[]).length;
    v.innerHTML = '<div class="card" style="display:flex;gap:12px;align-items:center"><img class="mine-avatar" src="'+Utils.esc(me.avatar)+'"/>' +
      '<div style="flex:1"><div style="font-weight:800;font-size:16px">'+Utils.esc(me.nickname)+' <span style="font-size:11px;color:var(--primary)">Demo 用户</span></div>' +
      '<div style="font-size:12px;color:var(--text-secondary)">'+Utils.esc(me.statusText||"")+' · 今日发出 '+sent+' 次 · 我的角色 '+mines+' 个</div></div></div>' +
      '<div class="card" style="margin-top:10px"><div class="row-between"><span>☀️ 主题（light / dark）</span><span><button class="chip '+(t==="light"?"active":"")+'" id="t-light">浅色</button> <button class="chip '+(t==="dark"?"active":"")+'" id="t-dark">深色</button></span></div>' +
      '<div class="row-between"><span>📮 接受集邮（'+(me.accepting?"开":"关")+'）</span><span class="switch '+(me.accepting?"on":"")+'" id="m-acc"></span></div>' +
      '<div class="field" style="margin-top:10px"><label>自定义状态标签</label><div style="display:flex;gap:8px"><input id="m-st" value="'+Utils.esc(me.statusText||"")+'" style="flex:1;background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:9px"/> <button class="btn btn-primary btn-small" id="m-save">保存</button></div></div></div>' +
      '<div class="card" style="margin-top:10px"><div class="row-between" id="m-his"><span>📮 我的集邮记录</span><span>›</span></div>' +
      '<div class="row-between" id="m-square"><span>🖼️ 广场（Mock 展示）</span><span>›</span></div>' +
      '<div class="row-between" id="m-map"><span>🗺️ 漫展平面地图</span><span>›</span></div>' +
      '<div class="row-between" id="m-about"><span>ℹ️ 关于漫展集邮</span><span>›</span></div></div>';
    document.getElementById("t-light").onclick=function(){Store.save("theme","light");applyTheme();render();};
    document.getElementById("t-dark").onclick=function(){Store.save("theme","dark");applyTheme();render();};
    document.getElementById("m-acc").onclick=function(){ me.accepting=!me.accepting; Store.save("currentUser",me); UI.toast(me.accepting?"已开始接受集邮":"已暂停接受集邮"); render(); };
    document.getElementById("m-save").onclick=function(){ me.statusText=document.getElementById("m-st").value.trim(); Store.save("currentUser",me); UI.toast("状态已保存"); render(); };
    document.getElementById("m-his").onclick=function(){Router.go("jipiao");};
    document.getElementById("m-square").onclick=function(){Router.go("square");};
    document.getElementById("m-map").onclick=function(){Router.go("map");};
    document.getElementById("m-about").onclick=function(){UI.showModal({title:"漫展集邮",content:"V1.0 Web Demo\n帮助 Coser 低门槛发现同场角色、一键发起集邮。",confirmText:"知道了"});};
  }

  /* ---------- 漫展选择 ---------- */
  function renderExhibitions(v){
    var cur = Store.get("currentExhibition", window.DEMO_EXHIBITIONS[0]);
    v.innerHTML = '<button class="btn btn-plain btn-small" id="e-back">‹ 返回</button><div class="section-head"><span>选择漫展</span></div>' +
      window.DEMO_EXHIBITIONS.map(function(ex){
        return '<div class="ex-item '+(ex.id===cur.id?"active":"")+'" data-ex="'+ex.id+'"><div class="t">'+Utils.esc(ex.name)+'</div><div class="s">'+Utils.esc(ex.location)+' · '+Utils.formatDateRange(ex.startTime,ex.endTime)+' · '+Utils.esc(ex.phaseText)+'</div></div>';
      }).join("");
    document.getElementById("e-back").onclick=function(){Router.go("home");};
    v.querySelectorAll("[data-ex]").forEach(function(c){ c.onclick=function(){
      var ex=window.DEMO_EXHIBITIONS.find(function(x){return x.id===c.getAttribute("data-ex");});
      Store.save("currentExhibition",ex); S.ip="全部"; S.area="全部"; S.status=""; S.keyword="";
      UI.toast("已切换到「"+ex.name+"」"); Router.go("home");
    };});
  }

  /* ---------- 模拟漫展平面地图 ---------- */
  function renderMap(v){
    var ex = Store.get("currentExhibition", window.DEMO_EXHIBITIONS[0]);
    var roles = State.allRoles();
    var zones = ex.zones||[];
    var colors = ["#FF85B3","#7FB3FF","#7BD88F","#E8B44A","#B48CFF","#6FD3D0"];
    var zoneH = 120, W = 640, padT = 30;
    var H = padT + zones.length*zoneH + 20;
    var svg = '<svg class="map-svg" viewBox="0 0 '+W+' '+H+'">';
    zones.forEach(function(z,i){
      var y = padT + i*zoneH;
      svg += '<rect x="10" y="'+y+'" width="'+(W-20)+'" height="'+(zoneH-10)+'" rx="10" fill="var(--bg)" stroke="'+colors[i%colors.length]+'" stroke-width="2" stroke-dasharray="6 4"/>';
      svg += '<text x="24" y="'+(y+24)+'" font-size="14" font-weight="700" fill="'+colors[i%colors.length]+'">'+Utils.esc(z)+'</text>';
      var inZone = roles.filter(function(r){return r.area===z;});
      inZone.forEach(function(r,j){
        var cx = 70 + (j%5)*110, cy = y + 58 + Math.floor(j/5)*30;
        var initial = r.roleName.charAt(0);
        svg += '<g class="map-dot" data-role="'+r.id+'"><circle cx="'+cx+'" cy="'+cy+'" r="17" fill="'+colors[i%colors.length]+'"/><text x="'+cx+'" y="'+(cy+5)+'" text-anchor="middle" font-size="14" fill="#fff">'+Utils.esc(initial)+'</text><text x="'+cx+'" y="'+(cy+30)+'" text-anchor="middle" font-size="10" fill="var(--text)">'+Utils.esc(r.roleName)+'</text></g>';
      });
      if(!inZone.length) svg += '<text x="24" y="'+(y+60)+'" font-size="12" fill="var(--text-weak)">暂无角色</text>';
    });
    svg += '<text x="24" y="20" font-size="13" font-weight="700" fill="var(--text)">'+Utils.esc(ex.name)+' · 模拟平面图（非真实地图）</text></svg>';
    v.innerHTML = '<button class="btn btn-plain btn-small" id="map-back">‹ 返回首页</button><div style="height:8px"></div><div class="map-wrap">'+svg+'<div style="font-size:12px;color:var(--text-secondary);margin-top:8px">A区/B区/舞台区/摄影区示意 · 点击头像进入角色详情</div></div>';
    document.getElementById("map-back").onclick=function(){Router.go("home");};
    v.querySelectorAll("[data-role]").forEach(function(g){ g.addEventListener("click",function(){ Router.go("detail",{id:g.getAttribute("data-role")}); }); });
  }

  /* ---------- 广场（Mock 展示） ---------- */
  function renderSquare(v){
    v.innerHTML = '<button class="btn btn-plain btn-small" id="s-back">‹ 返回</button><div class="section-head"><span>广场 · Mock 展示</span><span class="count">仅展示，不做真实发布/点赞</span></div>' +
      window.DEMO_POSTS.map(function(p){
        return '<div class="post"><div style="font-weight:700;font-size:13px">'+Utils.esc(p.nickname)+' <span style="color:var(--primary);font-weight:400">· '+Utils.esc(p.tag)+'</span></div><div style="font-size:13px;margin-top:4px">'+Utils.esc(p.content)+'</div>' +
        (p.images.length?'<div class="imgs">'+p.images.map(function(s){return '<img src="'+s+'"/>';}).join("")+'</div>':"") +
        '<div style="font-size:12px;color:var(--text-weak);margin-top:6px">❤ '+p.likeCount+' · '+Utils.formatRelative(p.createdAt)+'</div></div>';
      }).join("");
    document.getElementById("s-back").onclick=function(){Router.go("home");};
  }

  window.App = { render:render, applyTheme:applyTheme, toggleTheme:toggleTheme };
})();
