/* js/utils.js - 沿用 utils/util.js 时间/防抖/uuid，toast 改自制 */
(function(){
  function pad(n){ return n<10?"0"+n:""+n; }
  function formatRelative(ts){
    if(!ts) return "";
    var diff = Date.now()-ts, M=60000, H=3600000, D=86400000;
    if(diff<M) return "刚刚";
    if(diff<H) return Math.floor(diff/M)+"分钟前";
    if(diff<D) return Math.floor(diff/H)+"小时前";
    if(diff<2*D) return "昨天";
    var d=new Date(ts); return pad(d.getMonth()+1)+"-"+pad(d.getDate());
  }
  function formatDateRange(s,e){
    if(!s||!e) return "";
    var a=new Date(s), b=new Date(e);
    return a.getFullYear()+" "+pad(a.getMonth()+1)+"."+pad(a.getDate())+" - "+pad(b.getMonth()+1)+"."+pad(b.getDate());
  }
  function debounce(fn,wait){ var t=null; return function(){ var a=arguments,c=this; if(t)clearTimeout(t); t=setTimeout(function(){fn.apply(c,a);},wait||300); }; }
  function uuid(p){ return (p||"id")+"_"+Date.now()+"_"+Math.floor(Math.random()*100000); }
  function esc(s){ return String(s===undefined||s===null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
  window.Utils = { formatRelative:formatRelative, formatDateRange:formatDateRange, debounce:debounce, uuid:uuid, esc:esc };
})();
