/* js/router.js - 页面状态切换（替代小程序端页面跳转），传统脚本 */
(function(){
  var current = "home";
  var params = {};
  var listeners = [];
  function go(page, p){
    current = page; params = p||{};
    listeners.forEach(function(fn){ fn(page, params); });
    window.scrollTo(0,0);
  }
  function onChange(fn){ listeners.push(fn); }
  function get(){ return { page:current, params:params }; }
  window.Router = { go:go, onChange:onChange, get:get };
})();
