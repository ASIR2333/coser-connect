/* js/state.js - 全局状态：首次加载 Mock 落库，之后读写 localStorage */
(function(){
  function nickname(id){
    if(id==="u_me") return (Store.get("currentUser", window.DEMO_ME)||window.DEMO_ME).nickname;
    var u = window.DEMO_USERS.find(function(x){return x.id===id;});
    return u?u.nickname:"";
  }
  function ensureInit(){
    if(!Store.get("inited", false)){
      Store.save("theme","light");
      Store.save("currentUser", window.DEMO_ME);
      Store.save("currentExhibition", window.DEMO_EXHIBITIONS[0]);
      Store.save("requests", window.DEMO_REQUESTS);
      Store.save("messages", window.DEMO_MESSAGES);
      Store.save("customRoles", []);
      Store.save("inited", true);
    }
  }
  function allRoles(){
    var ex = Store.get("currentExhibition", window.DEMO_EXHIBITIONS[0]);
    var seeds = window.DEMO_ROLES.filter(function(r){return r.exhibitionId===ex.id;});
    var customs = Store.get("customRoles", []).filter(function(r){return r.exhibitionId===ex.id;});
    return seeds.concat(customs);
  }
  function allRequests(){ return Store.get("requests", []); }
  function saveRequests(l){ Store.save("requests", l); }
  function allMessages(){ return Store.get("messages", []); }
  function unreadCount(){ return allMessages().filter(function(m){return !m.read;}).length; }
  function pushMessage(type,title,content,roleId){
    var l = allMessages();
    l.unshift({ id:Utils.uuid("n"), type:type, title:title, content:content, roleId:roleId||"", read:false, createdAt:Date.now() });
    Store.save("messages", l);
  }
  window.State = { ensureInit:ensureInit, allRoles:allRoles, allRequests:allRequests, saveRequests:saveRequests,
    allMessages:allMessages, unreadCount:unreadCount, pushMessage:pushMessage, nickname:nickname };
})();
