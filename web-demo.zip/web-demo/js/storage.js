/* js/storage.js - localStorage 统一封装（替代 wx.setStorageSync），传统脚本 */
(function(){
  var PREFIX = "mc_";
  function save(key, value){ try{ localStorage.setItem(PREFIX+key, JSON.stringify(value)); }catch(e){} }
  function get(key, dv){
    try{
      var raw = localStorage.getItem(PREFIX+key);
      if(raw===null||raw===undefined||raw==="") return dv;
      return JSON.parse(raw);
    }catch(e){ return dv; }
  }
  function remove(key){ try{ localStorage.removeItem(PREFIX+key); }catch(e){} }
  window.Store = { save:save, get:get, remove:remove };
})();
