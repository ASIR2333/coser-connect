/* js/components/toast.js + modal.js + loading/empty/status/role-card/request-card/exhibition-card */
(function(){
  var toastTimer = null;
  function toast(msg){
    var el = document.getElementById("toast");
    el.textContent = msg; el.style.display = "block";
    if(toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function(){ el.style.display="none"; }, 2000);
  }
  /* modal: options {title, content, showInput, inputValue, confirmText} -> Promise({confirm, value}) */
  function showModal(o){
    return new Promise(function(resolve){
      var mask = document.getElementById("modal-mask");
      var esc = Utils.esc;
      mask.innerHTML = '<div class="modal"><h3>'+esc(o.title||"提示")+'</h3><p>'+esc(o.content||"")+'</p>' +
        (o.showInput?'<textarea id="m-input" placeholder="'+esc(o.placeholder||"说点什么吧～")+'">'+esc(o.inputValue||"")+'</textarea>':"") +
        '<div class="row"><button class="btn btn-plain" id="m-cancel">取消</button><button class="btn btn-primary" id="m-ok">'+esc(o.confirmText||"确定")+'</button></div></div>';
      mask.classList.add("show");
      function close(v){ mask.classList.remove("show"); mask.innerHTML=""; resolve(v); }
      document.getElementById("m-cancel").onclick = function(){ close({confirm:false}); };
      document.getElementById("m-ok").onclick = function(){
        var v = o.showInput ? document.getElementById("m-input").value : "";
        close({confirm:true, value:v});
      };
      mask.onclick = function(e){ if(e.target===mask) close({confirm:false}); };
    });
  }
  function statusTag(s, text){
    var map = { available:"status-available", busy:"status-busy", rest:"status-rest" };
    return '<span class="status-tag '+(map[s]||"status-rest")+'">'+Utils.esc(text||s)+'</span>';
  }
  function reqStatusTag(s){
    var m = { pending:["status-busy","待处理"], accepted:["status-available","已接受"], rejected:["status-rest","已拒绝"] };
    var v = m[s]||m.pending;
    return '<span class="status-tag '+v[0]+'">'+v[1]+'</span>';
  }
  function roleCard(r, mode){
    var esc = Utils.esc;
    if(mode==="list"){
      return '<div class="role-list-item" data-role="'+r.id+'"><img src="'+esc(r.avatar)+'" alt=""/>'+
        '<div style="flex:1"><div style="font-weight:700">'+esc(r.roleName)+'</div>'+
        '<div style="font-size:12px;color:var(--primary)">'+esc(r.ip)+'</div>'+
        '<div style="font-size:12px;color:var(--text-secondary)">'+esc(r.area)+'</div></div>'+
        '<div>'+statusTag(r.status,r.statusText)+'</div></div>';
    }
    return '<div class="role-card" data-role="'+r.id+'"><img class="cover" src="'+esc(r.avatar)+'" alt=""/>'+
      '<div class="body"><div class="name">'+esc(r.roleName)+'</div>'+
      '<div class="ip">'+esc(r.ip)+'</div><div class="area">'+esc(r.area)+'</div>'+
      statusTag(r.status,r.statusText)+'</div></div>';
  }
  function requestCard(r){
    var esc = Utils.esc, s = r.roleSnapshot||{};
    var dir = r.senderId==="u_me" ? "我 → "+esc(s.ownerNickname||"") : esc(State.nickname(r.senderId))+" → 我";
    var ops = "";
    if(r.status==="pending" && r.receiverId==="u_me"){
      ops = '<div class="ops"><button class="btn btn-primary btn-small" data-accept="'+r.id+'">接受</button><button class="btn btn-plain btn-small" data-reject="'+r.id+'">拒绝</button></div>';
    } else if(r.status==="pending" && r.senderId==="u_me"){
      ops = '<div class="ops"><button class="btn btn-plain btn-small" data-sim="'+r.id+'">模拟对方接受</button></div>';
    }
    return '<div class="req-card"><div class="head"><img src="'+esc(s.avatar||"assets/images/avatar.png")+'"/>'+
      '<div style="flex:1"><div style="font-weight:700;font-size:14px">'+esc(s.roleName||"")+' <span style="font-weight:400;font-size:12px;color:var(--primary)">'+esc(s.ip||"")+'</span></div>'+
      '<div style="font-size:12px;color:var(--text-secondary)">'+dir+' · '+Utils.formatRelative(r.createdAt)+'</div></div>'+
      reqStatusTag(r.status)+'</div>'+
      (r.message?'<div class="msg">留言：'+esc(r.message)+'</div>':"")+ops+'</div>';
  }
  function exhibitionCard(ex){
    return '<div class="ex-card" id="ex-card"><div class="pin">🎌</div><div><div class="t1">'+Utils.esc(ex.name)+'</div>'+
      '<div class="t2">'+Utils.esc(ex.location)+' · '+Utils.formatDateRange(ex.startTime,ex.endTime)+' · '+Utils.esc(ex.phaseText||"")+'</div></div>'+
      '<span class="go">切换 ›</span></div>';
  }
  function emptyState(big, text, sub, btnText, btnId){
    return '<div class="empty"><div class="big">'+big+'</div><div style="font-weight:700;color:var(--text)">'+Utils.esc(text)+'</div>'+
      '<div style="font-size:12px;margin:6px 0 14px">'+Utils.esc(sub||"")+'</div>'+
      (btnText?'<button class="btn btn-primary btn-small" id="'+btnId+'">'+Utils.esc(btnText)+'</button>':"")+'</div>';
  }
  window.UI = { toast:toast, showModal:showModal, statusTag:statusTag, reqStatusTag:reqStatusTag, roleCard:roleCard, requestCard:requestCard, exhibitionCard:exhibitionCard, emptyState:emptyState };
})();
